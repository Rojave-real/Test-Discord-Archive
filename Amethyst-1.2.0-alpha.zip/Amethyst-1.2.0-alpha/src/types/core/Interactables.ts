export enum CommandPermission {
    Administrator = "Administrator",

    RobloxModerator = "RobloxModerator",
    RobloxCommunityManager = "RobloxCommunityManager",

    PointsManager = "PointsManager",
    PointsViewer = "PointsViewer",
    PointlogCreator = "PointlogCreator",

    EventScheduler = "EventScheduler",
    ScheduleManager = "ScheduleManager",
}

export enum CommandModule {
    Developer = "Developer",
    Global = "Global",
    Guild = "Guild",
    Points = "Points",
    Schedule = "Schedule",
    Roblox = "Roblox",
}
