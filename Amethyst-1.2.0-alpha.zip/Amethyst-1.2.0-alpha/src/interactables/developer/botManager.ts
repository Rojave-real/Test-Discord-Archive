import { type APIEmbedField, SlashCommandSubcommandBuilder } from "discord.js";
import { ErrorEmbed, InfoEmbed, SuccessEmbed } from "../../classes/components/embeds/Embed.js";
import PageEmbed from "../../classes/components/embeds/PageEmbed.js";
import SlashCommand from "../../classes/interactables/SlashCommand.js";
import client from "../../main.js";
import { CommandModule } from "../../types/core/Interactables.js";

export default new SlashCommand({
    name: "botmanager",
    description: "sneaky sneaky",
    module: CommandModule.Developer,

    devOnly: true,
    userApp: true,

    subcommands: [
        new SlashCommandSubcommandBuilder()
            .setName("listguilds")
            .setDescription("Lists all guilds that the bot is in."),

        new SlashCommandSubcommandBuilder()
            .setName("registerguild")
            .setDescription("Registers a guild into the database.")
            .addStringOption((option) =>
                option.setName("guild-id").setDescription("The guild to register.").setRequired(true),
            )
            .addStringOption((option) =>
                option
                    .setName("shortname")
                    .setDescription("The shortname of the guild to be used in the database.")
                    .setRequired(true),
            ),
    ],

    function: async (interaction) => {
        const subcommand = interaction.options.getSubcommand(true);
        switch (subcommand) {
            case "listguilds":
                {
                    const guilds = await client.guilds.fetch();
                    const fields = [] as APIEmbedField[];

                    for (const guild of guilds.values()) {
                        const actualGuild = await client.Functions.fetchGuild(guild.id, false);
                        if (!actualGuild) continue;
                        const owner = await actualGuild.fetchOwner().then((owner) => owner.user);

                        fields.push({
                            name: actualGuild.name,
                            value: `[\`${actualGuild.id}\`](https://discord.com/channels/${actualGuild.id})\n(${owner.username}:\`${owner.id}\`)\n`,
                        });
                    }

                    const pageEmbed = new PageEmbed({
                        baseEmbed: new InfoEmbed({ title: "Guild List" }),
                        fields: fields,
                    });

                    await interaction.editReply(pageEmbed.getMessageData());
                }
                break;
            case "registerguild":
                {
                    const guildId = interaction.options.getString("guild-id", true);
                    const shortname = interaction.options.getString("shortname", true);

                    try {
                        await client.Database.addGuildProfile(shortname, guildId);

                        await interaction.editReply({
                            embeds: [
                                new SuccessEmbed({
                                    title: "Guild Registered",
                                    description: `Guild \`${guildId}\` has been registered with the shortname \`${shortname}\`.`,
                                }),
                            ],
                        });
                    } catch (error) {
                        const message = client.Functions.formatErrorMessage(error);
                        await interaction.editReply({
                            embeds: [
                                new ErrorEmbed({
                                    title: "Error while registering guild",
                                    description: message,
                                }),
                            ],
                        });
                    }
                }
                break;
        }
    },
});
