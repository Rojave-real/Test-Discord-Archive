import bcrypt from "bcrypt";
import { ButtonStyle, MessageFlags, SlashCommandSubcommandBuilder, StringSelectMenuOptionBuilder } from "discord.js";
import Button from "../../classes/components/Button.js";
import StringSelector from "../../classes/components/StringSelectMenu.js";
import ButtonEmbed from "../../classes/components/embeds/ButtonEmbed.js";
import { ErrorEmbed, InfoEmbed, SuccessEmbed } from "../../classes/components/embeds/Embed.js";
import PageEmbed from "../../classes/components/embeds/PageEmbed.js";
import APIKey from "../../classes/database/APIKey.js";
import SlashCommand from "../../classes/interactables/SlashCommand.js";
import client from "../../main.js";
import { RoutePermission } from "../../types/core/API.js";
import { CommandModule, CommandPermission } from "../../types/core/Interactables.js";

const routePermissionChoices = Object.entries(RoutePermission)
    .filter(([key]) => Number.isNaN(Number(key)))
    .map(([key, value]) => ({
        name: key.replace(/([A-Z])/g, " $1").trim(),
        value: value.toString(),
    }));

const routePermissionOptions = Object.entries(RoutePermission)
    .filter(([key]) => Number.isNaN(Number(key)))
    .map(([key, value]) =>
        new StringSelectMenuOptionBuilder().setLabel(key.replace(/([A-Z])/g, " $1").trim()).setValue(value.toString()),
    );

export default new SlashCommand({
    name: "manageapi",
    description: "Manage the API settings for the guild.",
    module: CommandModule.Guild,

    permissions: [CommandPermission.Administrator],
    subcommands: [
        new SlashCommandSubcommandBuilder()
            .setName("generatekey")
            .setDescription("Create a new API key")
            .addStringOption((option) =>
                option
                    .setName("name")
                    .setDescription("The name of the key")
                    .setRequired(true)
                    .setMaxLength(25)
                    .setAutocomplete(false),
            ),

        new SlashCommandSubcommandBuilder()
            .setName("managekey")
            .setDescription("Manage an API key")
            .addStringOption((option) =>
                option
                    .setName("key")
                    .setDescription("The key to manage")
                    .setRequired(true)
                    .setMaxLength(25)
                    .setAutocomplete(false),
            ),

        new SlashCommandSubcommandBuilder().setName("listkeys").setDescription("List all API keys"),
    ],

    function: async (interaction, guildProfile) => {
        if (!guildProfile || !interaction.guild) throw new Error("Unknown error");

        const subcommand = interaction.options.getSubcommand(true);
        switch (subcommand) {
            case "generatekey":
                {
                    const keys = await APIKey.getByGuild(interaction.guild.id);
                    if (keys.length > 25) {
                        await interaction.editReply({
                            embeds: [
                                new ErrorEmbed({
                                    title: "API Key Limit Reached",
                                    description: "You have reached the maximum number of API keys allowed.",
                                }),
                            ],
                        });
                        return;
                    }

                    const name = interaction.options.getString("name", true);
                    if (await APIKey.getByName(name, interaction.guild?.id)) {
                        await interaction.editReply({
                            embeds: [
                                new ErrorEmbed({
                                    title: "API Key already exists",
                                    description: "The key already exists.",
                                }),
                            ],
                        });
                        return;
                    }

                    const key = client.API.generateKey();

                    try {
                        client.Database.runTransaction(async (connection) => {
                            await connection.query(
                                `INSERT INTO APIKeys (\`name\`, \`value\`, guildId, createdBy)
                                VALUES (?, ?, ?, ?)`,
                                [name, await bcrypt.hash(key, 10), interaction.guild?.id, interaction.user.id],
                            );
                        });

                        const buttonEmbed = new ButtonEmbed(
                            new InfoEmbed({
                                title: "API Key Generated",
                                description: "Click the button below to reveal the key.",
                            }),
                        );
                        buttonEmbed.addButton(
                            new Button({
                                label: "Reveal Key",
                                style: ButtonStyle.Danger,
                            }).oncePressed(async (buttonInteraction) => {
                                await buttonInteraction.reply({
                                    flags: MessageFlags.Ephemeral,
                                    content: `||\`${key}\`||`,
                                });
                            }),
                        );

                        await interaction.user.send(buttonEmbed.getMessageData());
                        await interaction.editReply({ embeds: [new InfoEmbed({ title: "Check your DMs!" })] });
                    } catch (error) {
                        await interaction.editReply({
                            embeds: [
                                new ErrorEmbed({ title: "An Error occured", description: "I couldn't send you a DM!" }),
                            ],
                        });
                    }
                }
                break;

            case "managekey":
                {
                    const name = interaction.options.getString("key", true);
                    const apiKey = await APIKey.getByName(name, interaction.guild?.id);
                    if (!apiKey) {
                        await interaction.editReply({
                            embeds: [
                                new ErrorEmbed({ title: "API Key not found", description: "The key doesn't exist." }),
                            ],
                        });
                        return;
                    }

                    const buttonEmbed = new ButtonEmbed(
                        new InfoEmbed({ title: "API Key Management", description: "Use the buttons below to " }),
                    );
                    const updateEmbed = () => {
                        buttonEmbed.embed.setField("Name", apiKey.name, false);
                        buttonEmbed.embed.setField("Enabled", apiKey.enabled ? "`Yes`" : "`No`", false);

                        const permissions = apiKey.permissions
                            .map((permissionEnum) => {
                                const permissionName = routePermissionChoices.find(
                                    (choice) => choice.value === permissionEnum.toString(),
                                )?.name;
                                return permissionName || permissionEnum.toString();
                            })
                            .join(", ");
                        if (permissions.length > 0) {
                            buttonEmbed.embed.setField("Permissions", permissions, false);
                        } else buttonEmbed.embed.setField("Permissions", "`None`", false);

                        buttonEmbed.embed.setField("Created By", `<@${apiKey.createdBy}>`, false);
                        buttonEmbed.embed.setField(
                            "Created On",
                            `<t:${Math.round(apiKey.createdAt.getTime() / 1000)}:F>`,
                            false,
                        );
                    };
                    updateEmbed();

                    buttonEmbed.addButton(
                        new Button({
                            label: "Toggle Enabled",
                            style: ButtonStyle.Secondary,
                            allowedUsers: [interaction.user.id],
                        }).onPressed(async (buttonInteraction) => {
                            await buttonInteraction.deferUpdate();
                            apiKey.enabled = !apiKey.enabled;

                            updateEmbed();
                            await interaction.editReply(buttonEmbed.getMessageData());
                        }),
                    );

                    buttonEmbed.addButton(
                        new Button({
                            label: "Set Permissions",
                            style: ButtonStyle.Primary,
                            allowedUsers: [interaction.user.id],
                        }).onPressed(async (buttonInteraction) => {
                            const selector = new StringSelector({
                                Placeholder: "Select Permissions",
                                allowedUsers: [interaction.user.id],
                                Options: routePermissionOptions,

                                MaxValues: routePermissionOptions.length,
                                MinValues: 0,
                            });

                            const response = await selector.Prompt(
                                buttonInteraction,
                                new InfoEmbed({
                                    title: "Set Permissions",
                                    description: "Select permissions to set (leave blank to clear)",
                                }),
                            );

                            if (!response.values) return;
                            if (response.values.includes(RoutePermission.Administrator.toString()))
                                response.values = [RoutePermission.Administrator.toString()];
                            apiKey.permissions = response.values.map((value) => value as unknown as RoutePermission);

                            updateEmbed();
                            await interaction.editReply(buttonEmbed.getMessageData());
                        }),
                    );

                    buttonEmbed.nextRow();

                    buttonEmbed.addButton(
                        new Button({
                            label: "Save",
                            style: ButtonStyle.Success,
                            allowedUsers: [interaction.user.id],
                        }).onPressed(async (buttonInteraction) => {
                            await buttonInteraction.deferUpdate();
                            await apiKey.save();
                            await interaction.editReply({
                                embeds: [
                                    new SuccessEmbed({
                                        title: "API Key Saved",
                                        description: "The key has been saved.",
                                    }),
                                ],
                                components: [],
                            });
                        }),
                    );

                    buttonEmbed.addButton(
                        new Button({
                            label: "Delete",
                            style: ButtonStyle.Danger,
                            allowedUsers: [interaction.user.id],
                        }).onPressed(async (buttonInteraction) => {
                            await buttonInteraction.deferUpdate();
                            await apiKey.delete();
                            await interaction.editReply({
                                embeds: [
                                    new SuccessEmbed({
                                        title: "API Key Deleted",
                                        description: "The key has been deleted.",
                                    }),
                                ],
                                components: [],
                            });
                        }),
                    );

                    await interaction.editReply(buttonEmbed.getMessageData());
                }
                break;

            case "listkeys":
                {
                    const keys = await APIKey.getByGuild(interaction.guild.id);
                    const fields =
                        keys.length > 0
                            ? keys.map((key) => {
                                  return {
                                      name: key.name,
                                      value: `Created by: <@${key.createdBy}> | Created on: <t:${Math.round(key.createdAt.getTime() / 1000)}:F>`,
                                  };
                              })
                            : [{ name: "No keys found", value: "No keys found" }];

                    const pageEmbed = new PageEmbed({
                        baseEmbed: new InfoEmbed({ title: "API Key List" }),
                        fields: fields,
                    });
                    await interaction.editReply(pageEmbed.getMessageData());
                }
                break;
        }
    },

    autocomplete: async (interaction) => {
        return [];
    },
});
