import bcrypt from "bcrypt";
import client from "../../main.js";
import type { RoutePermission } from "../../types/core/API.js";

export type rawAPIKeyData = {
    id: bigint;
    __v: number;

    guildId: string;

    name: string;
    value: string;
    enabled: boolean;
    permissions: RoutePermission[];

    createdAt: Date;
    createdBy: string;
};

export default class APIKey {
    readonly id: bigint;
    private __v: number;

    readonly guildId: string;

    name: string;
    value: string;
    enabled: boolean;
    permissions: RoutePermission[];

    createdAt: Date;
    createdBy: string;

    constructor(rawdata: rawAPIKeyData) {
        this.id = rawdata.id;
        this.__v = rawdata.__v;

        this.guildId = rawdata.guildId;

        this.name = rawdata.name;
        this.value = rawdata.value;
        this.enabled = rawdata.enabled;
        this.permissions = rawdata.permissions;

        this.createdAt = rawdata.createdAt;
        this.createdBy = rawdata.createdBy;
    }

    public static async getByName(name: string, guildId: string): Promise<APIKey | undefined> {
        return await client.Database.runQuery(async (connection) => {
            const result = await connection.query<[rawAPIKeyData]>(
                "SELECT * FROM APIKeys WHERE `name` = ? AND guildId = ?",
                [name, guildId],
            );

            if (!result.length) return undefined;
            return new APIKey(result[0]);
        });
    }

    public static async getByValue(value: string): Promise<APIKey | undefined> {
        return await client.Database.runQuery(async (connection) => {
            const result = await connection.query<[rawAPIKeyData]>("SELECT * FROM APIKeys WHERE enabled = true");

            for (const rawdata of result) {
                const match = await bcrypt.compare(value, rawdata.value);
                if (match) {
                    return new APIKey(rawdata);
                }
            }

            return undefined;
        });
    }

    public static async getByGuild(guildId: string): Promise<APIKey[]> {
        return await client.Database.runQuery(async (connection) => {
            const result = await connection.query<[rawAPIKeyData]>("SELECT * FROM APIKeys WHERE guildId = ?", [
                guildId,
            ]);

            return result.map((rawdata) => new APIKey(rawdata));
        });
    }

    public async save(): Promise<void> {
        await client.Database.runTransaction(async (connection) => {
            const result = await connection.query(
                `INSERT INTO APIKeys (id, __v, guildId, name, value, enabled, permissions, createdAt, createdBy)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE
                __v = VALUES(__v),
                name = VALUES(name),
                value = VALUES(value),
                enabled = VALUES(enabled),
                permissions = VALUES(permissions),
                createdAt = VALUES(createdAt),
                createdBy = VALUES(createdBy)`,
                [
                    this.id,
                    this.__v,
                    this.guildId,
                    this.name,
                    this.value,
                    this.enabled,
                    JSON.stringify(this.permissions),
                    this.createdAt,
                    this.createdBy,
                ],
            );

            if (result.affectedRows === 0) {
                throw new Error("Save failed: The record was modified or does not exist.");
            }
            this.__v += 1;
        });
    }

    public async delete(): Promise<void> {
        await client.Database.runTransaction(async (connection) => {
            const result = await connection.query("DELETE FROM APIKeys WHERE id = ?", [this.id]);

            if (result.affectedRows === 0) {
                throw new Error("Delete failed: The record was modified or does not exist.");
            }
        });
    }
}
