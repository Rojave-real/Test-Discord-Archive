import Route from "../../../../../classes/Route.js";
import PointLog, { type rawPointLogData } from "../../../../../classes/database/PointLog.js";
import client from "../../../../../main.js";
import { RoutePermission } from "../../../../../types/core/API.js";

const parsePointlog = (rawData: Partial<rawPointLogData>): PointLog => {
    if (!rawData.creatorRobloxId) throw new Error("Missing creatorRobloxId.");
    if (!rawData.creatorRobloxUsername) throw new Error("Missing creatorRobloxUsername.");

    if (!rawData.data) throw new Error("Missing data");
    for (const data of rawData.data) {
        if (!data.user || !(data.user.robloxId || data.user.robloxUsername))
            throw new Error("Missing user data in entry.");
        if (Number.isNaN(Number(data.user.robloxId))) throw new Error(`Malformed robloxId: ${data.user.robloxId}`);

        data.points = Number(data.points);
        if (Number.isNaN(data.points))
            throw new Error(`Malformed point amount for ${data.user.robloxUsername}:${data.user.robloxId}`);
        if (data.points === 0)
            throw new Error(`${data.user.robloxUsername}:${data.user.robloxId}'s points cannot be equal to 0.`);
        if (data.points > Number.MAX_SAFE_INTEGER || data.points < Number.MIN_SAFE_INTEGER)
            throw new Error(
                `${data.user.robloxUsername}:${data.user.robloxId}'s points must be between ${Number.MIN_SAFE_INTEGER} and ${Number.MAX_SAFE_INTEGER}.`,
            );
    }

    rawData.id = rawData.id ?? client.Functions.GenerateUUID();
    if (rawData.id.length > 36) throw new Error("Pointlog id's max length is 36 characters.");
    rawData.createdAt = new Date();

    return new PointLog(rawData as rawPointLogData);
};

export default new Route({
    method: "POST",
    rateLimit: {
        limit: 5,
        windowMs: 60_000,
    },

    middlewares: [],
    public: false,
    permissions: [RoutePermission.PointlogCreator],

    function: async (req, res, guildProfile) => {
        if (!guildProfile)
            return res.status(503).json(client.API.formatError(503, "GuildProfile not found after validation"));

        try {
            if (!req.body) throw new Error("No data given.");

            const pointlog = parsePointlog(req.body);
            pointlog.guildId = guildProfile.id;

            const existingLog = await client.Database.getPointlog(pointlog.id);
            if (existingLog) throw new Error(`Pointlog with id ${pointlog.id} already exists.`);
            pointlog.save();

            res.sendStatus(200);
        } catch (error) {
            if (!(error instanceof Error)) return res.status(503).json(client.API.formatError(503, "Unknown error"));

            res.status(400).json(client.API.formatError(400, error.message));
        }
    },
});
