import Route from "../../../../../classes/Route.js";
import client from "../../../../../main.js";
import { RoutePermission } from "../../../../../types/core/API.js";

export default new Route({
    method: "GET",
    rateLimit: {
        limit: 100,
        windowMs: 60_000,
    },

    middlewares: [],
    public: false,
    permissions: [RoutePermission.PointsViewer],

    function: async (req, res, guildProfile) => {
        if (!guildProfile)
            return res.status(503).json(client.API.formatError(503, "GuildProfile not found after validation"));

        const robloxId = Number.parseInt(req.params.robloxId);
        if (!robloxId) {
            res.status(403).json(client.API.formatError(403, "Missing or Invalid RobloxId in the request"));
            return;
        }

        const guildUserProfile = await client.Database.getGuildUserProfile(guildProfile.id, robloxId);
        res.status(200).json({ points: guildUserProfile.points, pending: await guildUserProfile.fetchPendingPoints() });
    },
});
