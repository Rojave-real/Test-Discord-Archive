import { Buffer } from "node:buffer";
import { createCipheriv, createDecipheriv } from "node:crypto";
import process from "node:process";
import { AxiosError } from "axios";
import { UserAvatarHeadshotImageFormat, type UserAvatarHeadshotImageSize, type UserData } from "bloxwrap";
import { type Guild, GuildMember, type User } from "discord.js";
import { SqlError } from "mariadb";
import type Client from "../classes/Client.ts";

export default class Functions {
    client: Client;

    constructor(client: Client) {
        this.client = client;
    }

    fetchRobloxUser = async (searcher: string | number, useCache = true): Promise<UserData> => {
        if (typeof searcher === "string" && !/^\d+$/.test(searcher)) {
            const users = await this.client.BloxWrap.fetchUsersByUsernames(searcher, false, { useCache: false });
            if (!users.length) throw new Error(`Username "${searcher}" not found or invalid.`);
            searcher = users[0].id;
        } else if (typeof searcher === "string") {
            searcher = Number(searcher);
        }

        return await this.client.BloxWrap.fetchUserById(searcher as number, { useCache });
    };

    fetchRobloxUserAvatarHeadshot = async (
        userId: number,
        size: UserAvatarHeadshotImageSize,
        isCircular: boolean,
    ): Promise<string | undefined> => {
        try {
            return (
                await this.client.BloxWrap.fetchUserAvatarHeadshot(
                    userId,
                    size,
                    UserAvatarHeadshotImageFormat.Png,
                    isCircular,
                    { useCache: false },
                )
            )[0].imageUrl;
        } catch (error) {
            return undefined;
        }
    };

    fetchGuild = async (guildId: string, useCache = true) => {
        let guild: Guild | undefined;
        if (useCache) {
            guild = this.client.guilds.cache.get(guildId);
            if (guild) return guild;
        }
        try {
            guild = await this.client.guilds.fetch(guildId);
        } catch (err) {
            return undefined;
        }
        return guild;
    };

    fetchUser = async (searcher: string, guild?: Guild, self?: User) => {
        if (searcher.toLowerCase() === "self" || (searcher.toLowerCase() === "me" && self)) return self;
        if (searcher.startsWith("<@") && searcher.endsWith(">")) searcher = searcher.slice(2, -1);

        try {
            const user = await this.client.users.fetch(searcher);
            return user;
        } catch (err) {
            if (guild) {
                const found = await guild.members.fetch({ query: searcher, limit: 1 });
                if (found.size > 0) return found.first()?.user;
            }

            for (const user of this.client.users.cache.values()) {
                if (user.username.toLowerCase() === searcher.toLowerCase()) {
                    return user;
                }

                if (user.displayName.toLowerCase() === searcher.toLowerCase()) {
                    return user;
                }
            }
        }
    };

    fetchGuildMember = async (searcher: string, guild: Guild, self?: User | GuildMember) => {
        try {
            if (searcher.toLowerCase() === "self" || (searcher.toLowerCase() === "me" && self)) {
                if (self instanceof GuildMember) return self;

                return await guild.members.fetch(searcher);
            }

            return await guild.members.fetch(searcher);
        } catch (error) {
            return undefined;
        }
    };

    fetchChannel = async (searcher: string, guild?: Guild, limitToGuild = false) => {
        if (searcher.startsWith("<#") && searcher.endsWith(">")) searcher = searcher.slice(2, -1);
        if (searcher.startsWith("#")) searcher = searcher.slice(1);
        searcher = searcher.replace(/ /g, "-");

        try {
            const channel = await this.client.channels.fetch(searcher);
            if (!channel) throw new Error("Channel not found");

            if (!limitToGuild || !guild) return channel;

            if (!("guild" in channel)) throw new Error("Channel not found");
            if (channel.guild.id === guild.id) return channel;

            throw new Error("Channel not found");
        } catch (err) {
            if (guild) {
                for (const channel of guild.channels.cache.values()) {
                    if (channel.name.toLowerCase() === searcher.toLowerCase()) {
                        return channel;
                    }
                }
            }

            for (const channel of this.client.channels.cache.values()) {
                if (!("name" in channel)) continue;
                if (!channel.name) continue;
                if (channel.name.toLowerCase() === searcher.toLowerCase()) {
                    if (!limitToGuild || !guild) return channel;
                    if (!("guild" in channel)) continue;
                    if (channel.guild.id === guild.id) return channel;
                }
            }
        }

        return undefined;
    };

    fetchRole = async (searcher: string, guild: Guild) => {
        if (searcher.startsWith("<@&") && searcher.endsWith(">")) searcher = searcher.slice(3, -1);

        try {
            const role = await guild.roles.fetch(searcher);
            if (role) return role;
            throw new Error("Role not found");
        } catch (err) {
            for (const role of guild.roles.cache.values()) {
                if (role.name.toLowerCase() === searcher.toLowerCase()) {
                    return role;
                }
                if (role.id === searcher) {
                    return role;
                }
                if (role.name.toLowerCase().startsWith(searcher.toLowerCase())) {
                    return role;
                }
            }
        }
    };

    formatErrorMessage = (error: unknown): string => {
        let message = "Unknown error";

        if (error instanceof Error) {
            message = `[${error.name}]: ${error.message}`;
            this.client.error(error.stack);
        }

        if (error instanceof SqlError) {
            message = `[${error.code}]: ${error.sqlMessage}`;
        }

        if (error instanceof AxiosError) {
            message = `[${error.code}]: ${JSON.stringify(error.response?.data.errors)}`;
        }

        return message;
    };

    wait = async (ms: number) => {
        return new Promise((resolve) => setTimeout(resolve, ms));
    };

    clamp = (value: number, min: number, max: number) => {
        return Math.min(Math.max(value, min), max);
    };

    findKeyfromValue = (map: Map<unknown, unknown>, value: unknown) => {
        return [...map].find(([key, val]) => val === value)?.[0];
    };

    GenerateUUID = () => {
        return crypto.randomUUID();
    };

    MemoryUsage = () => {
        const used = process.memoryUsage().heapUsed / 1024 / 1024;
        return Math.round(used);
    };

    encypt = (text: string, iv: string) => {
        const key = Buffer.from(this.client.config.credentials.encryptionKey, "hex");
        const _iv = Buffer.from(iv, "hex");

        const cipher = createCipheriv("aes256", key, _iv);
        const encryptedMessage = cipher.update(text, "utf8", "hex") + cipher.final("hex");

        return encryptedMessage;
    };

    decrypt = (text: string, iv: string) => {
        const key = Buffer.from(this.client.config.credentials.encryptionKey, "hex");
        const _iv = Buffer.from(iv, "hex");

        const decipher = createDecipheriv("aes256", key, _iv);
        const decryptedMessage = decipher.update(text, "hex", "utf-8") + decipher.final("utf8");

        return decryptedMessage;
    };

    isDev = (userId: string) => {
        return this.client.config.devList.includes(userId);
    };
}
